#!/bin/bash

rand1=$(( $RANDOM % 100 ))
rand2=$(( $RANDOM % 100 ))
rand3=$(( $RANDOM % 100 ))
rand4=$(( $RANDOM % 100 ))
rand5=$(( $RANDOM % 100 ))
rand6=$(( $RANDOM % 100 ))

__scores="{\"Problem 1\": 1, \"Problem 2\": 2, \"Problem 3\": 3, \"Problem 4\": 4, \"Problem 5\": 5, \"Problem 6\": $rand6}"
__scoreboard="[1, 2, 3, 4, 5, $rand6]"
echo "{\"scores\":  $__scores, \"scoreboard\": $__scoreboard}"